@echo off
title Installateur ThaborSolution
echo ====================================================
echo    INSTALLATION DE THABORSOLUTION STOCK MANAGER
echo ====================================================
echo.
echo Verification de Python...
python --version >nul 2>&1
if %errorlevel% neq 0 (
    echo [ERREUR] Python n'est pas installe sur cette machine.
    echo Veuillez installer Python depuis https://www.python.org/
    pause
    exit
)

echo Lancement de la configuration automatique...
python setup.py
pause
